"""
نموذج PIML (Physics-Informed Machine Learning)
يوفر دوال فيزيائية لتوليد بيانات واقعية تعكس السيناريوهات الحرجة في مصنع الفوسفات
"""

import math
import numpy as np
from datetime import datetime, timedelta

class PIMLModel:
    """نموذج PIML لمحاكاة العمليات الفيزيائية في المصنع"""
    
    def __init__(self):
        # معاملات النظام الأساسية
        self.base_temperature = 25.0  # درجة الحرارة الأساسية (°C)
        self.base_pressure = 101325.0  # الضغط الأساسي (Pa)
        self.fouling_factor = 0.0  # عامل الترسبات (0-1)
        self.vibration_baseline = 50.0  # خط الاهتزاز الأساسي (Hz)
        self.time_step = 0  # خطوة زمنية للمحاكاة
        
        # معاملات الحساسات البرمجية
        self.cloth_blinding_level = 0.0  # مستوى انسداد القماش (0-1)
        self.pipe_scale_level = 0.0  # مستوى قشور الأنابيب (0-1)
        self.valve_bypass_level = 0.0  # مستوى التسريب الداخلي للصمام (0-1)
        
        # معاملات السلامة
        self.so2_level = 0.0  # مستوى SO2 (ppm)
        self.cui_risk_level = 0.0  # مستوى خطر التآكل تحت العزل (0-1)
        
    def calculate_fouling_factor(self, flow_rate, temp_in, temp_out):
        """
        حساب عامل مقاومة الترسبات (Fouling Resistance Factor)
        
        المنطق الفيزيائي:
        - الترسبات تزداد مع انخفاض معدل التدفق (تراكم أملاح)
        - الترسبات تزداد مع ارتفاع فرق درجة الحرارة (تبخر أسرع)
        
        Args:
            flow_rate: معدل التدفق (L/min)
            temp_in: درجة حرارة الدخول (°C)
            temp_out: درجة حرارة الخروج (°C)
        
        Returns:
            fouling_factor: عامل الترسبات (0-1)
        """
        # معادلة فيزيائية مبسطة
        # كلما قل التدفق وزاد فرق الحرارة، زاد الترسب
        
        if flow_rate <= 0:
            flow_rate = 0.1
        
        temp_difference = abs(temp_out - temp_in)
        
        # حساب معدل الترسب النسبي
        fouling_rate = (temp_difference / 50.0) * (30.0 / flow_rate)
        
        # تحديث عامل الترسبات بشكل تراكمي (يزداد مع الوقت)
        self.fouling_factor = min(1.0, self.fouling_factor + fouling_rate * 0.01)
        
        # إذا كان معدل التدفق عالياً، ينظف الترسبات تدريجياً
        if flow_rate > 25:
            self.fouling_factor = max(0.0, self.fouling_factor - 0.005)
        
        return self.fouling_factor
    
    def detect_cloth_blinding(self, vacuum_pressure, acid_flow):
        """
        كشف انسداد القماش (Cloth Blinding) في الفلتر
        
        المنطق الفيزيائي:
        - الضغط العالي مع التدفق المنخفض = انسداد القماش
        
        Args:
            vacuum_pressure: ضغط الفراغ (Pa)
            acid_flow: تدفق الحمض (L/min)
        
        Returns:
            dict: حالة الانسداد والتوصيات
        """
        # تحديد حد الضغط والتدفق
        pressure_threshold = 80000  # Pa
        flow_threshold = 5  # L/min
        
        is_blinding = (vacuum_pressure > pressure_threshold) and (acid_flow < flow_threshold)
        
        if is_blinding:
            self.cloth_blinding_level = min(1.0, self.cloth_blinding_level + 0.05)
        else:
            self.cloth_blinding_level = max(0.0, self.cloth_blinding_level - 0.02)
        
        return {
            "detected": is_blinding,
            "severity": self.cloth_blinding_level,
            "recommendation": "تفعيل غسيل انتقائي للقماش" if is_blinding else "النظام سليم",
            "affected_pan": self._identify_affected_pan() if is_blinding else None
        }
    
    def detect_pipe_scale(self, drainage_speed_current, drainage_speed_baseline):
        """
        كشف قشور الأنابيب من خلال مراقبة سرعة التصريف
        
        المنطق الفيزيائي:
        - إذا استغرق التصريف وقتاً أطول من المعتاد = وجود قشور
        
        Args:
            drainage_speed_current: سرعة التصريف الحالية (mm/s)
            drainage_speed_baseline: سرعة التصريف الأساسية (mm/s)
        
        Returns:
            dict: حالة القشور والتوصيات
        """
        if drainage_speed_baseline <= 0:
            drainage_speed_baseline = 10.0
        
        # حساب النسبة المئوية للانخفاض
        speed_ratio = drainage_speed_current / drainage_speed_baseline
        
        # إذا انخفضت السرعة بأكثر من 30%، هناك قشور
        has_scale = speed_ratio < 0.7
        
        if has_scale:
            self.pipe_scale_level = min(1.0, self.pipe_scale_level + 0.03)
        else:
            self.pipe_scale_level = max(0.0, self.pipe_scale_level - 0.01)
        
        return {
            "detected": has_scale,
            "severity": self.pipe_scale_level,
            "speed_ratio": speed_ratio,
            "recommendation": "جدولة تنظيف الأنابيب" if has_scale else "الأنابيب سليمة",
            "estimated_cleaning_date": self._estimate_cleaning_date() if has_scale else None
        }
    
    def detect_valve_bypass(self, valve_status, acoustic_frequency):
        """
        كشف التسريب الداخلي للصمام من خلال التحليل الصوتي
        
        المنطق الفيزيائي:
        - الصمام مغلق لكن هناك ترددات صوتية عالية = تسريب غير مرئي
        
        Args:
            valve_status: حالة الصمام ("open" أو "closed")
            acoustic_frequency: التردد الصوتي (Hz)
        
        Returns:
            dict: حالة التسريب والتوصيات
        """
        # الترددات العالية (> 20 kHz) تشير إلى تسريب
        high_frequency_threshold = 20000  # Hz
        
        has_bypass = (valve_status == "closed") and (acoustic_frequency > high_frequency_threshold)
        
        if has_bypass:
            self.valve_bypass_level = min(1.0, self.valve_bypass_level + 0.04)
        else:
            self.valve_bypass_level = max(0.0, self.valve_bypass_level - 0.02)
        
        return {
            "detected": has_bypass,
            "severity": self.valve_bypass_level,
            "acoustic_frequency": acoustic_frequency,
            "recommendation": "استبدال الصمام فوراً" if has_bypass else "الصمام سليم",
            "risk_level": "critical" if has_bypass else "normal"
        }
    
    def calculate_cui_risk(self, surface_temperature, ambient_temperature, isolation_age_days):
        """
        حساب خطر التآكل تحت العزل (CUI - Corrosion Under Insulation)
        
        المنطق الفيزيائي:
        - الفرق الكبير بين درجة حرارة السطح والمحيط + العزل القديم = خطر CUI
        
        Args:
            surface_temperature: درجة حرارة السطح (°C)
            ambient_temperature: درجة الحرارة المحيطة (°C)
            isolation_age_days: عمر العزل (أيام)
        
        Returns:
            dict: مستوى الخطر والتوصيات
        """
        temp_difference = abs(surface_temperature - ambient_temperature)
        
        # حساب خطر CUI
        # كلما زاد فرق الحرارة وعمر العزل، زاد الخطر
        cui_risk = (temp_difference / 100.0) * (isolation_age_days / 1000.0)
        self.cui_risk_level = min(1.0, cui_risk)
        
        risk_level = "low" if self.cui_risk_level < 0.3 else ("medium" if self.cui_risk_level < 0.7 else "high")
        
        return {
            "risk_level": risk_level,
            "severity": self.cui_risk_level,
            "temp_difference": temp_difference,
            "isolation_age_days": isolation_age_days,
            "recommendation": "فحص العزل والأنابيب بالكاميرا الحرارية" if self.cui_risk_level > 0.5 else "استمرار المراقبة"
        }
    
    def calculate_so2_emissions(self, reactor_temperature, acid_flow, oxygen_level):
        """
        حساب مستوى انبعاثات SO2 بناءً على ظروف التشغيل
        
        المنطق الفيزيائي:
        - درجة حرارة أعلى + تدفق حمض أعلى = انبعاثات SO2 أعلى
        
        Args:
            reactor_temperature: درجة حرارة المفاعل (°C)
            acid_flow: تدفق الحمض (L/min)
            oxygen_level: مستوى الأكسجين (%)
        
        Returns:
            dict: مستوى SO2 والتوصيات
        """
        # معادلة فيزيائية مبسطة
        base_so2 = 5.0  # ppm أساسي
        
        # تأثير درجة الحرارة
        temp_factor = max(0, (reactor_temperature - 20) / 100.0)
        
        # تأثير التدفق
        flow_factor = acid_flow / 50.0
        
        # تأثير الأكسجين
        oxygen_factor = oxygen_level / 100.0
        
        self.so2_level = base_so2 + (temp_factor * flow_factor * oxygen_factor * 100)
        
        # تحديد مستوى الخطر
        if self.so2_level > 50:
            severity = "critical"
        elif self.so2_level > 20:
            severity = "warning"
        else:
            severity = "normal"
        
        return {
            "so2_level": self.so2_level,
            "severity": severity,
            "recommendation": "تفعيل نظام التهوية" if severity != "normal" else "النظام ضمن الحدود",
            "health_impact": "خطر على الصحة" if severity == "critical" else "آمن"
        }
    
    def apply_2oo3_voting_logic(self, sensor1_alert, sensor2_alert, sensor3_alert):
        """
        تطبيق منطق التكرار والتصويت (2oo3)
        يتطلب توافق حساسين من أصل ثلاثة قبل تفعيل الإغلاق الطارئ
        
        Args:
            sensor1_alert: تنبيه الحساس الأول (bool)
            sensor2_alert: تنبيه الحساس الثاني (bool)
            sensor3_alert: تنبيه الحساس الثالث (bool)
        
        Returns:
            dict: قرار النظام
        """
        alert_count = sum([sensor1_alert, sensor2_alert, sensor3_alert])
        
        if alert_count >= 2:
            decision = "CONFIRMED_ALARM_SHUTDOWN"
            confidence = alert_count / 3.0
        else:
            decision = "WARNING_CHECK_SENSORS"
            confidence = alert_count / 3.0
        
        return {
            "decision": decision,
            "alert_count": alert_count,
            "confidence": confidence,
            "action": "تفعيل الإغلاق الطارئ" if decision == "CONFIRMED_ALARM_SHUTDOWN" else "فحص الحساسات"
        }
    
    def _identify_affected_pan(self):
        """تحديد رقم اللوح المصاب (محاكاة)"""
        return np.random.randint(1, 13)  # 12 لوح في الفلتر
    
    def _estimate_cleaning_date(self):
        """تقدير تاريخ التنظيف المقترح"""
        days_to_clean = max(1, int(7 - (self.pipe_scale_level * 7)))
        return (datetime.now() + timedelta(days=days_to_clean)).strftime("%Y-%m-%d")
    
    def generate_realistic_data(self):
        """
        توليد بيانات واقعية بناءً على نموذج PIML
        
        Returns:
            dict: بيانات المحاكاة الواقعية
        """
        self.time_step += 1
        
        # محاكاة دورة تشغيلية
        cycle_position = (self.time_step % 100) / 100.0
        
        # درجات الحرارة (مع تذبذب طبيعي)
        temp_in = self.base_temperature + 15 + 10 * math.sin(cycle_position * 2 * math.pi)
        temp_out = temp_in - 5 - 3 * math.sin(cycle_position * 2 * math.pi)
        
        # معدل التدفق (مع تغيرات طبيعية)
        flow_rate = 20 + 8 * math.sin(cycle_position * 2 * math.pi)
        
        # الضغط (يزداد مع الترسبات)
        fouling = self.calculate_fouling_factor(flow_rate, temp_in, temp_out)
        pressure = self.base_pressure + 5000 * fouling + 2000 * math.sin(cycle_position * 2 * math.pi)
        
        # الاهتزاز (يزداد مع عدم التوازن)
        vibration = self.vibration_baseline + 50 * fouling + 30 * math.sin(cycle_position * 4 * math.pi)
        
        # كشف الأعطال
        cloth_blinding = self.detect_cloth_blinding(pressure, flow_rate)
        pipe_scale = self.detect_pipe_scale(15 - 5 * fouling, 15)
        valve_bypass = self.detect_valve_bypass("closed", 15000 + 5000 * fouling)
        cui_risk = self.calculate_cui_risk(temp_in, self.base_temperature, 365)
        so2_emissions = self.calculate_so2_emissions(temp_in, flow_rate, 21)
        
        return {
            "temp_in": round(temp_in, 2),
            "temp_out": round(temp_out, 2),
            "flow_rate": round(flow_rate, 2),
            "pressure": round(pressure, 0),
            "vibration": round(vibration, 2),
            "fouling_factor": round(fouling, 3),
            "cloth_blinding": cloth_blinding,
            "pipe_scale": pipe_scale,
            "valve_bypass": valve_bypass,
            "cui_risk": cui_risk,
            "so2_emissions": so2_emissions,
            "source": "PIML_Simulated"
        }


# مثال على الاستخدام
if __name__ == "__main__":
    model = PIMLModel()
    
    for i in range(10):
        data = model.generate_realistic_data()
        print(f"\n--- Step {i+1} ---")
        print(f"Temperature: {data['temp_in']}°C -> {data['temp_out']}°C")
        print(f"Flow Rate: {data['flow_rate']} L/min")
        print(f"Pressure: {data['pressure']} Pa")
        print(f"Vibration: {data['vibration']} Hz")
        print(f"Fouling Factor: {data['fouling_factor']}")
        print(f"Cloth Blinding: {data['cloth_blinding']['detected']}")
        print(f"SO2 Level: {data['so2_emissions']['so2_level']:.1f} ppm")
