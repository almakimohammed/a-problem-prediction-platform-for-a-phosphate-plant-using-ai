import os
import logging
import random
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from openai import OpenAI
from piml_model import PIMLModel

# إعدادات التطبيق
app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mining_digital_twin.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# إعداد OpenAI
client = OpenAI(api_key="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")

# إعداد نموذج PIML
piml = PIMLModel()

# إعداد السجلات
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Alert thresholds (configurable)
VIBRATION_ALERT_THRESHOLD = float(os.getenv('VIBRATION_ALERT_THRESHOLD', 30.0))
PRESSURE_ALERT_THRESHOLD = float(os.getenv('PRESSURE_ALERT_THRESHOLD', 102000.0))
TEMP_OBJECT_ALERT_THRESHOLD = float(os.getenv('TEMP_OBJECT_ALERT_THRESHOLD', 50.0))

# ============================================================================
# نماذج قاعدة البيانات (Database Models)
# ============================================================================

class Reading(db.Model):
    """سجل قراءات الحساسات"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    temp_bmp280 = db.Column(db.Float)
    temp_ds18b20 = db.Column(db.Float)
    temp_dht22 = db.Column(db.Float)
    temp_ambient_thermal = db.Column(db.Float)
    temp_object_thermal = db.Column(db.Float)
    pressure = db.Column(db.Float)
    humidity = db.Column(db.Float)
    altitude = db.Column(db.Float)
    flow_rate = db.Column(db.Float)
    vibration = db.Column(db.Float)
    relief_valve_open = db.Column(db.Boolean)
    pump_running = db.Column(db.Boolean)
    alarm_active = db.Column(db.Boolean)
    # حقول PIML الجديدة
    fouling_factor = db.Column(db.Float)
    so2_level = db.Column(db.Float)
    source = db.Column(db.String(50), default="Real") # Real or Simulated
    thermal_matrix = db.Column(db.JSON) # مصفوفة البيانات الحرارية الكاملة

    def to_dict(self):
        data = {c.name: getattr(self, c.name) for c in self.__table__.columns}
        return data

class Alert(db.Model):
    """سجل التنبيهات والأحداث"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    alert_type = db.Column(db.String(50))
    severity = db.Column(db.String(20)) # normal, warning, critical
    message = db.Column(db.Text)
    value = db.Column(db.Float)
    threshold = db.Column(db.Float)
    action_taken = db.Column(db.String(100))
    module = db.Column(db.String(50)) # Reactor, Filtration, Safety

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

class Prediction(db.Model):
    """سجل تنبؤات الذكاء الاصطناعي (GPT-4)"""
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    content = db.Column(db.Text)
    risk_level = db.Column(db.String(20)) # منخفض، متوسط، مرتفع

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

class MaintenanceSchedule(db.Model):
    """جدول الصيانة الاستباقية"""
    id = db.Column(db.Integer, primary_key=True)
    target_device = db.Column(db.String(100))
    issue_type = db.Column(db.String(100))
    recommended_date = db.Column(db.String(50))
    status = db.Column(db.String(20), default="Pending")

    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

# ============================================================================
# نقاط النهاية (API Endpoints)
# ============================================================================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/readings', methods=['GET', 'POST'])
def handle_readings():
    if request.method == 'POST':
        data = request.json

        # Enforce real sensor data by default. Reject simulation requests via API.
        if data.get('simulate'):
            return jsonify({'status': 'error', 'message': 'Simulation via API is disabled. Run mock_data.py locally to send simulated readings.'}), 400
        source_val = data.get('source')
        if isinstance(source_val, str) and 'simulated' in source_val.lower():
            # Allow simulated posts only from localhost (loopback) or when the
            # simulator sends a local-only header `X-Local-Simulator: true`.
            remote = (request.remote_addr or '').lower()
            header_ok = request.headers.get('X-Local-Simulator', '').lower() == 'true'
            is_local = remote.startswith('127.') or remote == '::1' or remote == 'localhost'
            if not (is_local or header_ok):
                return jsonify({'status': 'error', 'message': 'Simulated source not accepted via network. Run simulator locally or include X-Local-Simulator header.'}), 400

        # PIML may only be invoked by server-side maintenance or explicit admin actions; do not call here.
        piml_data = None

        # Helper to safely fetch nested piml values
        def pget(key, default=None):
            if not piml_data:
                return default
            return piml_data.get(key, default)

        new_reading = Reading(
            temp_bmp280=(data.get('temp_bmp280') if data.get('temp_bmp280') is not None else pget('temp_in')),
            temp_ds18b20=(data.get('temp_ds18b20') if data.get('temp_ds18b20') is not None else pget('temp_out')),
            temp_dht22=data.get('temp_dht22'),
            temp_ambient_thermal=(data.get('temp_ambient_thermal') if data.get('temp_ambient_thermal') is not None else (pget('cui_risk') and pget('cui_risk').get('temp_difference') if pget('cui_risk') else None)),
            temp_object_thermal=(data.get('temp_object_thermal') if data.get('temp_object_thermal') is not None else pget('temp_in')),
            pressure=(data.get('pressure') if data.get('pressure') is not None else pget('pressure')),
            humidity=data.get('humidity'),
            altitude=data.get('altitude'),
            flow_rate=(data.get('flow_rate') if data.get('flow_rate') is not None else pget('flow_rate')),
            vibration=(data.get('vibration') if data.get('vibration') is not None else pget('vibration')),
            relief_valve_open=data.get('relief_valve_open', False),
            pump_running=data.get('pump_running', True),
            alarm_active=data.get('alarm_active', False),
            fouling_factor=(pget('fouling_factor') if pget('fouling_factor') is not None else data.get('fouling_factor')),
            so2_level=(pget('so2_emissions') and pget('so2_emissions').get('so2_level') if pget('so2_emissions') else data.get('so2_level')),
            source=data.get('source', 'Real'),
            thermal_matrix=data.get('thermal_matrix')
        )
        db.session.add(new_reading)
        db.session.commit()
        
        # تطبيق منطق 2oo3 Voting للتنبيهات الحرجة
        # استخدم حدوداً قابلة للتهيئة وتأكد من التعامل مع قيم None بأمان
        vib_val = float(new_reading.vibration) if new_reading.vibration is not None else 0.0
        pres_val = float(new_reading.pressure) if new_reading.pressure is not None else 0.0
        temp_val = float(new_reading.temp_object_thermal) if new_reading.temp_object_thermal is not None else 0.0

        vibration_alert = vib_val > VIBRATION_ALERT_THRESHOLD
        pressure_alert = pres_val > PRESSURE_ALERT_THRESHOLD
        temp_alert = temp_val > TEMP_OBJECT_ALERT_THRESHOLD

        voting = piml.apply_2oo3_voting_logic(vibration_alert, pressure_alert, temp_alert)

        if voting['decision'] == "CONFIRMED_ALARM_SHUTDOWN":
            alert = Alert(
                alert_type="Emergency Shutdown",
                severity="critical",
                message=f"2oo3 Logic Confirmed Danger: {voting['alert_count']} sensors triggered.",
                module="Safety",
                action_taken="System Shutdown Initiated",
                value=max(vib_val, pres_val, temp_val),
                threshold=max(VIBRATION_ALERT_THRESHOLD, PRESSURE_ALERT_THRESHOLD, TEMP_OBJECT_ALERT_THRESHOLD)
            )
            db.session.add(alert)
            db.session.commit()
        elif voting['alert_count'] > 0:
            # سجل تحذير إذا كان هناك واحد أو اثنان من الحساسات مشغلة (للمراقبة)
            alert = Alert(
                alert_type="2oo3 Warning",
                severity="warning",
                message=f"2oo3 Warning: {voting['alert_count']} sensors triggered. Check sensors.",
                module="Safety",
                action_taken="Inspect sensors",
                value=max(vib_val, pres_val, temp_val),
                threshold=max(VIBRATION_ALERT_THRESHOLD, PRESSURE_ALERT_THRESHOLD, TEMP_OBJECT_ALERT_THRESHOLD)
            )
            db.session.add(alert)
            db.session.commit()
            
        return jsonify(new_reading.to_dict()), 201
    
    readings = Reading.query.order_by(Reading.timestamp.desc()).limit(50).all()
    return jsonify([r.to_dict() for r in readings])


def _is_request_local_or_trusted():
    """Return True when the request originates from loopback or includes the simulator header."""
    remote = (request.remote_addr or '').lower()
    header_ok = request.headers.get('X-Local-Simulator', '').lower() == 'true'
    is_local = remote.startswith('127.') or remote == '::1' or remote == 'localhost'
    return is_local or header_ok

@app.route('/api/dashboard/summary')
def get_summary():
    # Prefer the latest real reading for dashboard display to avoid simulator
    # overwriting visible values when both real sensors and local simulator run.
    latest_reading = Reading.query.filter_by(source='Real').order_by(Reading.timestamp.desc()).first()
    if not latest_reading:
        latest_reading = Reading.query.order_by(Reading.timestamp.desc()).first()
    latest_prediction = Prediction.query.order_by(Prediction.timestamp.desc()).first()
    # Include PIML status only when explicitly requested and from a trusted source
    include_piml = request.args.get('include_piml', 'false').lower() == 'true'
    piml_status = None
    if include_piml and _is_request_local_or_trusted():
        try:
            piml_status = piml.generate_realistic_data()
        except Exception as e:
            logger.warning(f"Failed to generate PIML status: {e}")

    return jsonify({
        'latest_reading': latest_reading.to_dict() if latest_reading else None,
        'latest_prediction': latest_prediction.to_dict() if latest_prediction else None,
        'piml_status': piml_status
    })


@app.route('/api/piml')
def get_piml_sample():
    """Return a single PIML sample — available only from localhost or trusted simulator header."""
    if not _is_request_local_or_trusted():
        return jsonify({'status': 'error', 'message': 'PIML data not available from remote hosts.'}), 403
    try:
        data = piml.generate_realistic_data()
        return jsonify(data)
    except Exception as e:
        logger.error(f"PIML generation error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/alerts', methods=['GET', 'POST'])
def handle_alerts():
    if request.method == 'POST':
        data = request.json
        new_alert = Alert(**data)
        db.session.add(new_alert)
        db.session.commit()
        return jsonify(new_alert.to_dict()), 201
    
    alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(20).all()
    return jsonify([a.to_dict() for a in alerts])

@app.route('/api/predict', methods=['POST'])
def predict_faults():
    """استخدام GPT-4 للتنبؤ بالأعطال بناءً على بيانات PIML والحساسات"""
    recent_readings = Reading.query.order_by(Reading.timestamp.desc()).limit(5).all()
    if not recent_readings:
        return jsonify({'status': 'error', 'message': 'No data available'}), 400
    
    data_summary = []
    for r in recent_readings:
        data_summary.append(f"Time: {r.timestamp}, Temp: {r.temp_object_thermal}C, Pressure: {r.pressure}Pa, Vibration: {r.vibration}Hz, Fouling: {r.fouling_factor}, SO2: {r.so2_level}")
    
    prompt = f"""
    أنت خبير صيانة تنبؤية في مصنع فوسفات. حلل البيانات التالية من التوأم الرقمي:
    البيانات:
    {chr(10).join(data_summary)}
    
    قدم تقريراً مختصراً باللغة العربية يتضمن:
    1. مستوى الخطر (منخفض، متوسط، مرتفع).
    2. الأعطال المحتملة (مثل: انسداد الفلتر، تآكل الأنابيب، ترسبات المفاعل).
    3. الإجراءات الوقائية الموصى بها.
    """
    
    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        prediction_text = response.choices[0].message.content
        
        risk = "منخفض"
        if "مرتفع" in prediction_text or "عالي" in prediction_text: risk = "مرتفع"
        elif "متوسط" in prediction_text: risk = "متوسط"
        
        new_prediction = Prediction(content=prediction_text, risk_level=risk)
        db.session.add(new_prediction)
        
        # إضافة صيانة مجدولة إذا كان الخطر مرتفعاً
        if risk == "مرتفع":
            new_maint = MaintenanceSchedule(
                target_device="Reactor/Filter",
                issue_type="AI Predicted Critical Fault",
                recommended_date=(datetime.now()).strftime("%Y-%m-%d")
            )
            db.session.add(new_maint)
            
        db.session.commit()
        return jsonify(new_prediction.to_dict()), 200
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/maintenance')
def get_maintenance():
    schedules = MaintenanceSchedule.query.all()
    return jsonify([s.to_dict() for s in schedules])

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)
