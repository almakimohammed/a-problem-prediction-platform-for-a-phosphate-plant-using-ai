/**
 * Thermal Camera Viewer
 * عرض بيانات الكاميرا الحرارية (MLX90640) كصورة ملونة (Heatmap) في الوقت الفعلي
 */

class ThermalViewer {
    constructor(canvasId, width = 32, height = 24) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.width = width;  // دقة MLX90640 الأفقية
        this.height = height; // دقة MLX90640 الرأسية
        this.pixelSize = 20;  // حجم كل بكسل في الشاشة
        
        // تعيين حجم الـ Canvas
        this.canvas.width = this.width * this.pixelSize;
        this.canvas.height = this.height * this.pixelSize;
        
        // مصفوفة البيانات الحرارية (768 قيمة = 32 × 24)
        this.thermalData = new Array(this.width * this.height).fill(20);
        
        // نطاق درجات الحرارة
        this.minTemp = 15;
        this.maxTemp = 100;
    }
    
    /**
     * تحويل درجة الحرارة إلى لون RGB باستخدام مقياس الألوان الحراري
     * (أزرق = بارد، أحمر = ساخن)
     */
    temperatureToColor(temp) {
        // تطبيع درجة الحرارة بين 0 و 1
        const normalized = (temp - this.minTemp) / (this.maxTemp - this.minTemp);
        const clamped = Math.max(0, Math.min(1, normalized));
        
        let r, g, b;
        
        if (clamped < 0.25) {
            // أزرق إلى أخضر
            r = 0;
            g = Math.floor(clamped * 4 * 255);
            b = 255;
        } else if (clamped < 0.5) {
            // أخضر إلى أصفر
            r = Math.floor((clamped - 0.25) * 4 * 255);
            g = 255;
            b = Math.floor((1 - (clamped - 0.25) * 4) * 255);
        } else if (clamped < 0.75) {
            // أصفر إلى برتقالي
            r = 255;
            g = Math.floor((1 - (clamped - 0.5) * 4) * 255);
            b = 0;
        } else {
            // برتقالي إلى أحمر
            r = 255;
            g = Math.floor((1 - (clamped - 0.75) * 4) * 128);
            b = 0;
        }
        
        return `rgb(${Math.floor(r)}, ${Math.floor(g)}, ${Math.floor(b)})`;
    }
    
    /**
     * تحديث بيانات الكاميرا الحرارية وإعادة رسم الصورة
     * @param {Array} data - مصفوفة البيانات الحرارية (768 قيمة)
     */
    updateThermalData(data) {
        if (!Array.isArray(data) || data.length !== this.width * this.height) {
            console.error(`Invalid thermal data. Expected ${this.width * this.height} values, got ${data.length}`);
            return;
        }
        
        this.thermalData = data;
        
        // تحديث نطاق درجات الحرارة تلقائياً
        this.minTemp = Math.min(...data);
        this.maxTemp = Math.max(...data);
        
        // إذا كانت جميع القيم متساوية، أضف هامش صغير
        if (this.minTemp === this.maxTemp) {
            this.minTemp -= 1;
            this.maxTemp += 1;
        }
        
        this.render();
    }
    
    /**
     * رسم الصورة الحرارية على الـ Canvas
     */
    render() {
        for (let y = 0; y < this.height; y++) {
            for (let x = 0; x < this.width; x++) {
                const index = y * this.width + x;
                const temp = this.thermalData[index];
                const color = this.temperatureToColor(temp);
                
                this.ctx.fillStyle = color;
                this.ctx.fillRect(
                    x * this.pixelSize,
                    y * this.pixelSize,
                    this.pixelSize,
                    this.pixelSize
                );
                
                // رسم حدود خفيفة بين البكسلات (اختياري)
                this.ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
                this.ctx.lineWidth = 0.5;
                this.ctx.strokeRect(
                    x * this.pixelSize,
                    y * this.pixelSize,
                    this.pixelSize,
                    this.pixelSize
                );
            }
        }
        
        // رسم شريط المقياس (Color Scale Bar)
        this.drawColorScale();
    }
    
    /**
     * رسم شريط المقياس الحراري على جانب الصورة
     */
    drawColorScale() {
        const scaleWidth = 30;
        const scaleHeight = this.canvas.height;
        const scaleX = this.canvas.width + 10;
        
        for (let i = 0; i < scaleHeight; i++) {
            const normalized = 1 - (i / scaleHeight);
            const temp = this.minTemp + normalized * (this.maxTemp - this.minTemp);
            const color = this.temperatureToColor(temp);
            
            this.ctx.fillStyle = color;
            this.ctx.fillRect(scaleX, i, scaleWidth, 1);
        }
        
        // رسم نصوص المقياس
        this.ctx.fillStyle = '#fff';
        this.ctx.font = '10px Arial';
        this.ctx.fillText(`${this.maxTemp.toFixed(1)}°C`, scaleX + 5, 15);
        this.ctx.fillText(`${this.minTemp.toFixed(1)}°C`, scaleX + 5, scaleHeight - 5);
    }
    
    /**
     * الحصول على أقصى درجة حرارة في المصفوفة
     */
    getMaxTemperature() {
        return Math.max(...this.thermalData);
    }
    
    /**
     * الحصول على أقل درجة حرارة في المصفوفة
     */
    getMinTemperature() {
        return Math.min(...this.thermalData);
    }
    
    /**
     * الحصول على متوسط درجة الحرارة
     */
    getAverageTemperature() {
        const sum = this.thermalData.reduce((a, b) => a + b, 0);
        return sum / this.thermalData.length;
    }
}

// تهيئة عارض الكاميرا الحرارية عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    const thermalViewer = new ThermalViewer('thermal-canvas', 32, 24);
    
    // دالة لتحديث الكاميرا الحرارية من البيانات المستقبلة
    function updateThermalCamera() {
        fetch('/api/dashboard/summary')
            .then(response => response.json())
            .then(data => {
                if (data.latest_reading && data.latest_reading.thermal_matrix) {
                    // إذا كانت البيانات تحتوي على مصفوفة حرارية كاملة
                    thermalViewer.updateThermalData(data.latest_reading.thermal_matrix);
                    
                    // تحديث الإحصائيات
                    document.getElementById('thermal-max').innerText = 
                        thermalViewer.getMaxTemperature().toFixed(1);
                    document.getElementById('thermal-avg').innerText = 
                        thermalViewer.getAverageTemperature().toFixed(1);
                    document.getElementById('thermal-min').innerText = 
                        thermalViewer.getMinTemperature().toFixed(1);
                } else if (data.latest_reading) {
                    // إذا كانت البيانات تحتوي فقط على قيمة واحدة، قم بإنشاء مصفوفة محاكاة
                    const mockData = generateMockThermalMatrix(
                        data.latest_reading.temp_object_thermal || 50
                    );
                    thermalViewer.updateThermalData(mockData);
                    
                    document.getElementById('thermal-max').innerText = 
                        thermalViewer.getMaxTemperature().toFixed(1);
                    document.getElementById('thermal-avg').innerText = 
                        thermalViewer.getAverageTemperature().toFixed(1);
                    document.getElementById('thermal-min').innerText = 
                        thermalViewer.getMinTemperature().toFixed(1);
                }
            })
            .catch(error => console.error('Error updating thermal camera:', error));
    }
    
    // دالة لإنشاء مصفوفة حرارية محاكاة بناءً على درجة حرارة واحدة
    function generateMockThermalMatrix(centerTemp) {
        const width = 32;
        const height = 24;
        const matrix = new Array(width * height);
        
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const index = y * width + x;
                // إضافة تذبذب عشوائي حول درجة الحرارة المركزية
                const variance = Math.random() * 10 - 5;
                matrix[index] = centerTemp + variance;
            }
        }
        
        return matrix;
    }
    
    // تحديث الكاميرا الحرارية كل 1 ثانية
    updateThermalCamera();
    setInterval(updateThermalCamera, 1000);
});
