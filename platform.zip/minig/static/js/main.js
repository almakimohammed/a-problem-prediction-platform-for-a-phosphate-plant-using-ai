document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('liveChart').getContext('2d');
    const liveChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'حرارة المفاعل (°C)',
                borderColor: '#ff6384',
                backgroundColor: 'rgba(255, 99, 132, 0.1)',
                data: [],
                fill: true,
                tension: 0.4
            }, {
                label: 'الضغط (Pa/1000)',
                borderColor: '#36a2eb',
                data: [],
                fill: false,
                tension: 0.4
            }, {
                label: 'الاهتزاز (Hz)',
                borderColor: '#ffcd56',
                data: [],
                fill: false,
                tension: 0.4
            }, {
                label: 'SO2 (ppm)',
                borderColor: '#4bc0c0',
                data: [],
                fill: false,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { labels: { color: '#e9ecef' } } },
            scales: {
                x: { grid: { color: '#333' }, ticks: { color: '#adb5bd' } },
                y: { grid: { color: '#333' }, ticks: { color: '#adb5bd' } }
            }
        }
    });

    function updateDashboard() {
        fetch('/api/dashboard/summary?include_piml=true')
            .then(response => response.json())
            .then(data => {
                if (data.latest_reading) {
                    const r = data.latest_reading;
                    document.getElementById('temp-value').innerText = (r.temp_object_thermal !== null && r.temp_object_thermal !== undefined) ? r.temp_object_thermal.toFixed(1) : '--';
                    document.getElementById('pressure-value').innerText = (r.pressure !== null && r.pressure !== undefined) ? r.pressure.toFixed(0) : '--';
                    document.getElementById('vibration-value').innerText = (r.vibration !== null && r.vibration !== undefined) ? r.vibration.toFixed(0) : '--';
                    document.getElementById('so2-value').innerText = (r.so2_level !== null && r.so2_level !== undefined) ? r.so2_level.toFixed(1) : '--';
                    
                    // Update PIML Indicators
                    if (r.fouling_factor !== undefined) {
                        const foulingPercent = (r.fouling_factor * 100).toFixed(1);
                        document.getElementById('fouling-val').innerText = foulingPercent + '%';
                        document.getElementById('fouling-bar').style.width = foulingPercent + '%';
                    }
                    
                    // Update Data Source
                    document.getElementById('data-source').innerText = `المصدر: ${r.source || 'Real'}`;

                    // Update Thermal Stats
                    document.getElementById('thermal-max').innerText = (r.temp_object_thermal !== null && r.temp_object_thermal !== undefined) ? r.temp_object_thermal.toFixed(1) : '--';
                    document.getElementById('thermal-avg').innerText = (r.temp_ambient_thermal !== null && r.temp_ambient_thermal !== undefined) ? r.temp_ambient_thermal.toFixed(1) : '--';

                    // Update Chart
                    const now = new Date().toLocaleTimeString();
                    if (liveChart.data.labels.length > 15) {
                        liveChart.data.labels.shift();
                        liveChart.data.datasets.forEach(d => d.data.shift());
                    }
                    liveChart.data.labels.push(now);
                    liveChart.data.datasets[0].data.push((r.temp_object_thermal !== null && r.temp_object_thermal !== undefined) ? r.temp_object_thermal : null);
                    liveChart.data.datasets[1].data.push((r.pressure !== null && r.pressure !== undefined) ? (r.pressure / 1000) : null);
                    liveChart.data.datasets[2].data.push((r.vibration !== null && r.vibration !== undefined) ? r.vibration : null);
                    liveChart.data.datasets[3].data.push((r.so2_level !== null && r.so2_level !== undefined) ? r.so2_level : null);
                    liveChart.update();
                }

                if (data.latest_prediction) {
                    const p = data.latest_prediction;
                    const card = document.getElementById('prediction-card');
                    card.className = `card p-3 risk-${p.risk_level === 'مرتفع' ? 'high' : (p.risk_level === 'متوسط' ? 'medium' : 'low')}`;
                    document.getElementById('prediction-content').innerText = p.content;
                }
                
                // Update CUI Risk from PIML Status if available
                if (data.piml_status && data.piml_status.cui_risk) {
                    const cuiPercent = (data.piml_status.cui_risk.severity * 100).toFixed(1);
                    document.getElementById('cui-val').innerText = cuiPercent + '%';
                    document.getElementById('cui-bar').style.width = cuiPercent + '%';
                }
            });

        fetch('/api/alerts')
            .then(response => response.json())
            .then(alerts => {
                const list = document.getElementById('alerts-list');
                list.innerHTML = '';
                alerts.slice(-4).reverse().forEach(alert => {
                    const item = document.createElement('div');
                    item.className = `list-group-item bg-transparent border-secondary text-light mb-1 rounded`;
                    item.style.borderRight = `4px solid ${alert.severity === 'critical' ? '#dc3545' : '#ffc107'}`;
                    item.innerHTML = `
                        <div class="d-flex w-100 justify-content-between">
                            <strong class="mb-1 small">${alert.alert_type}</strong>
                            <small style="font-size: 0.7rem;">${new Date(alert.timestamp).toLocaleTimeString()}</small>
                        </div>
                        <p class="mb-0" style="font-size: 0.75rem; opacity: 0.8;">${alert.message}</p>
                    `;
                    list.appendChild(item);
                });
            });
    }

    // AI Prediction Trigger
    document.getElementById('predict-btn').addEventListener('click', function() {
        const btn = this;
        const loading = document.getElementById('prediction-loading');
        const content = document.getElementById('prediction-content');
        
        btn.disabled = true;
        loading.classList.remove('d-none');
        content.classList.add('d-none');

        fetch('/api/predict', { method: 'POST' })
            .then(r => r.json())
            .then(data => {
                updateDashboard();
            })
            .finally(() => {
                btn.disabled = false;
                loading.classList.add('d-none');
                content.classList.remove('d-none');
            });
    });

    // Initial update and interval
    updateDashboard();
    setInterval(updateDashboard, 3000);
    document.getElementById('refresh-btn').addEventListener('click', updateDashboard);
});
