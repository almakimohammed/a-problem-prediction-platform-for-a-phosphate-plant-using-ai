import requests
import time
import random
from piml_model import PIMLModel

API_URL = "http://127.0.0.1:5000/api/readings"
ALERT_URL = "http://127.0.0.1:5000/api/alerts"

def generate_mock_data():
    # إنشاء كائن PIML لتوليد بيانات واقعية
    piml = PIMLModel()
    
    print("Starting PIML-based Mock Data Generator...")
    
    while True:
        # توليد بيانات واقعية بناءً على المعادلات الفيزيائية
        piml_data = piml.generate_realistic_data()
        
        # تجهيز البيانات للإرسال
        data = {
            "temp_bmp280": piml_data["temp_in"],
            "temp_ds18b20": piml_data["temp_out"],
            "temp_object_thermal": piml_data["temp_in"] + random.uniform(-1, 1),
            "temp_ambient_thermal": piml_data["temp_out"] - 5,
            "pressure": piml_data["pressure"],
            "vibration": piml_data["vibration"],
            "flow_rate": piml_data["flow_rate"],
            "fouling_factor": piml_data.get("fouling_factor"),
            "so2_level": piml_data.get("so2_emissions", {}).get("so2_level"),
            "source": "Simulated (PIML)"
        }
        
        try:
            # إرسال القراءات (حدد رأس يبيّن أن المرسل هو المحاكي المحلي)
            headers = {'X-Local-Simulator': 'true'}
            response = requests.post(API_URL, json=data, headers=headers)
            
            # التحقق من وجود أعطال مكتشفة بواسطة PIML لإرسال تنبيهات
            if piml_data["cloth_blinding"]["detected"]:
                requests.post(ALERT_URL, json={
                    "alert_type": "Cloth Blinding",
                    "severity": "warning",
                    "message": piml_data["cloth_blinding"]["recommendation"],
                    "module": "Filtration",
                    "value": piml_data["cloth_blinding"]["severity"]
                }, headers=headers)
                
            if piml_data["so2_emissions"]["severity"] == "critical":
                requests.post(ALERT_URL, json={
                    "alert_type": "High SO2 Emissions",
                    "severity": "critical",
                    "message": piml_data["so2_emissions"]["recommendation"],
                    "module": "Safety",
                    "value": piml_data["so2_emissions"]["so2_level"]
                }, headers=headers)
                
            if piml_data["fouling_factor"] > 0.7:
                requests.post(ALERT_URL, json={
                    "alert_type": "High Fouling Factor",
                    "severity": "warning",
                    "message": "Fouling resistance factor exceeded threshold. Adjusting temp.",
                    "module": "Reactor",
                    "value": piml_data["fouling_factor"]
                }, headers=headers)

        except Exception as e:
            print(f"Error sending data: {e}")
        
        time.sleep(3)

if __name__ == "__main__":
    generate_mock_data()
